
import { useState } from 'react';

const gameSteps = [
  { title: "🗺️ Sõrmede saar", prompt: "Te sattusite saarele, kus kõik noodid on peidetud! Üks neist asub 2. positsioonis A-keelel ja teeb sellise heli: E. Kes oskab selle leida ja mängida?" },
  { title: "🌪️ Vibrato vulkaan", prompt: "Vulkaan ärkab, kui kõlab ühtlane vibrato rütm tempoga ♩=60. Võlupoogna hoidja peab esitama 3 noodi vibratoga, igaüks 4 löögi pikkune. Kas vulkaan jääb magama või purskab?" },
  { title: "🗿 Nootide tempel", prompt: "Sisenedes templisse kuulete müstilist motiivi: C – E – G – A. Looge sellest lühike meloodia, kus igaüks mängib ühe noodi." },
  { title: "🧙 Improvisatsiooni koobas", prompt: "Koopas heliseb müütiline harmoonia. Improvisatsioonimeister alustab fraasi 2. keelel, millele iga järgmine liige lisab ühe kõrgema noodi." },
  { title: "🏰 Kontserdi loss", prompt: "Looge pala, kus iga noot on seotud ühe sõnaga: Kevad – ärkab – vaikuses – helin. Esitage see kui lõppkontsert." },
];

function App() {
  const [step, setStep] = useState(0);
  return (
    <div className="p-6 max-w-xl mx-auto text-center">
      <h1 className="text-3xl font-bold mb-6">Tšelloseiklus: GPT saarel</h1>
      <div className="bg-white shadow p-4 mb-4 rounded-lg">
        <strong>{gameSteps[step].title}</strong>
        <p className="mt-2">{gameSteps[step].prompt}</p>
      </div>
      <div className="flex justify-center gap-4">
        <button disabled={step === 0} onClick={() => setStep(step - 1)}>Eelmine</button>
        <button disabled={step === gameSteps.length - 1} onClick={() => setStep(step + 1)}>Järgmine</button>
      </div>
    </div>
  );
}

export default App;
